---
title: Cache
template: default
expires: 0

access:
    admin.cache: true
    admin.super: true
    admin.maintenance: true
---
